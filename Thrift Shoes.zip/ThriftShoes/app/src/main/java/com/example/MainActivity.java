package com.example;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    Db_Controller db;
    EditText ed1,ed2;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=new Db_Controller(this,"",null,1);
    }
    public void doAction(View view) {
        switch(view.getId()){
            case R.id.add:
                Intent i=new Intent(this,Add.class);
                startActivity(i);
                break;
            case R.id.show:
                Intent in=new Intent(this,Display.class);
                startActivity(in);
                break;
            case R.id.search:
                Intent inn=new Intent(this,Search.class);
                startActivity(inn);
                break;
            case R.id.delete:
                Intent n=new Intent(this,Delete.class);
                startActivity(n);
                break;


        }
    }
}