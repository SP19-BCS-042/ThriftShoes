package com.example;

public class ShoeModel {
    String name;
    String price;
    String serialNo;
    byte[] image;

    public ShoeModel() {
    }

    public ShoeModel(String name, String price, String serialNo, byte[] image) {
        this.name = name;
        this.price = price;
        this.serialNo = serialNo;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
}
