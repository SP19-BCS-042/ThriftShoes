package com.example;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class Add extends AppCompatActivity {
    Db_Controller db;
    EditText ed3,ed4,ed5;

    Bitmap bitmap;
    ImageView ivSelectedImage;
    FloatingActionButton fabSelectImage;

    ActivityResultLauncher<Intent> mLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    // Do your code from onActivityResult

                    if(result.getData() != null && result.getResultCode() == RESULT_OK) {
                        InputStream inputStream = null;
                        try {
                            inputStream = getApplicationContext().getContentResolver().openInputStream(result.getData().getData());
                            bitmap = BitmapFactory.decodeStream(inputStream);
                            ivSelectedImage.setImageBitmap(bitmap);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }

                    }
                }
            });

    public static byte[] getBytes(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);


        fabSelectImage = findViewById(R.id.fab_select_image);
        ivSelectedImage = findViewById(R.id.iv_selected_image);
        ed3=findViewById(R.id.editText3);
        ed4=findViewById(R.id.editText4);
        ed5=findViewById(R.id.editText5);

        fabSelectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);

                Intent chooserIntent = Intent.createChooser(intent, "Select picture");
                mLauncher.launch(chooserIntent);
            }
        });

    }


    public void add(View view) {
        db=new Db_Controller(this,"",null,1);
        try{
        }catch(SQLiteException e){
            Toast.makeText(this,"already",Toast.LENGTH_SHORT).show();
        }

        if(bitmap == null) {
            Toast.makeText(getApplicationContext(), "Select image", Toast.LENGTH_SHORT).show();
            return;
        }

        db.insert_shoes(ed3.getText().toString(),ed4.getText().toString(),ed5.getText().toString(), getBytes(bitmap));
        Toast.makeText(this,"data inserted",Toast.LENGTH_SHORT).show();
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
    }

}
