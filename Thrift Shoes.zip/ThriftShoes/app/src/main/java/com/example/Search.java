package com.example;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Search extends AppCompatActivity {
    TextView tv;
    Db_Controller db;
    EditText ed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }
    public void btn_search(View view) {
        db = new Db_Controller(this, "", null, 1);
        ed = findViewById(R.id.ed_search);
        tv = findViewById(R.id.tv_search);
        String text = ed.getText().toString();
        db.search(tv, text);
    }
}
