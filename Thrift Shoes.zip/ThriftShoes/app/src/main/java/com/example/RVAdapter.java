package com.example;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.MyViewHolder> {
    ArrayList<ShoeModel> shoes;
    Context context;

    public RVAdapter() {
    }

    public RVAdapter(ArrayList<ShoeModel> shoes, Context context) {
        this.shoes = shoes;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listItem = inflater.inflate(R.layout.single_shoe, parent, false);
        return new MyViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final ShoeModel shoe = shoes.get(position);

        holder.tvName.setText(shoe.getName());
        holder.tvSerialNo.setText("Serial Number:" + shoe.getSerialNo());
        holder.tvPrice.setText("Price is: " + shoe.getPrice());

        holder.iv.setImageBitmap(getImage(shoe.getImage()));
    }

    
    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }

    @Override
    public int getItemCount() {
        return shoes.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvName, tvSerialNo, tvPrice;
        ImageView iv;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.tv_name);
            tvSerialNo = itemView.findViewById(R.id.tv_serial_no);
            tvPrice = itemView.findViewById(R.id.tv_price);
            iv = itemView.findViewById(R.id.iv_selected_image);


        }
    }
}