package com.example;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Display extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<ShoeModel> shoes = new ArrayList<ShoeModel>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        rv = findViewById(R.id.rv_all_shoes);

        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        Db_Controller controller = new Db_Controller(getApplicationContext(),"",null,1);
        shoes = controller.show();

        RVAdapter adapter = new RVAdapter(shoes, getApplicationContext());
        rv.setAdapter(adapter);
    }
}
