package com.example;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class Db_Controller extends SQLiteOpenHelper {
    public Db_Controller(Context context, String name,SQLiteDatabase.CursorFactory factory,int version) {
        super(context, "e.db", factory, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE TShoes(SHOENAME TEXT,PRICE TEXT,SERIAL TEXT, IMAGE BLOB);");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS TShoes;");
    }
    public void insert_shoes(String shoe_name,String price,String serial, byte[] image){
        ContentValues con=new ContentValues();
        con.put("SHOENAME",shoe_name);
        con.put("PRICE",price);
        con.put("SERIAL",serial);
        con.put("IMAGE", image);

        this.getWritableDatabase().insertOrThrow("TShoes","",con);
    }
    public void delete_student(String shoe_name){

        this.getWritableDatabase().delete("TShoes","SHOENAME='"+shoe_name+"'",null);

    }
    public ArrayList<ShoeModel> show(){
        ArrayList<ShoeModel> shoes = new ArrayList<ShoeModel>();

        Cursor cursor=
                this.getReadableDatabase().rawQuery("SELECT * FROM TShoes ",null);

        while(cursor.moveToNext()){
            ShoeModel shoe = new ShoeModel(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getBlob(3));
            shoes.add(shoe);
        }

        return shoes;
    }
    public void search(TextView tv,String s_name){
        Cursor cursor=
                this.getReadableDatabase().rawQuery("SELECT * FROM TShoe WHERE SHOENAME='"+s_name+"'",null);
                        tv.setText("");
        while(cursor.moveToNext()){
            tv.append("Name: "+cursor.getString(0)+" Price: "+cursor.getString(1)+" Serial: "+cursor.getString(2)+"\n");
        }
    }
}