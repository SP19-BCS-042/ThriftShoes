package com.example;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Delete extends AppCompatActivity {
    Db_Controller db;
    EditText ed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
    }
    public void btn_delete(View view) {
        db=new Db_Controller(this,"",null,1);
        ed=findViewById(R.id.ed_delete);
        String text=ed.getText().toString();
        db.delete_student(text);
        Toast.makeText(this,"Deleted Successfully",Toast.LENGTH_SHORT).show();
                Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
    }
}
